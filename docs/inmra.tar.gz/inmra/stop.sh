#!/bin/sh

if [ -f ./SYSTEM_RUNNING ]
then
  echo "found a pid, with contents $(cat pid_inmra).  Killing that process id"
  # kill the application by reading the process id from the "pid_inmra"
  # file and "kill"-ing it (regular kill is nice.  we're not kill -9'ing here!)
  kill $(cat pid_inmra)

  echo "deleting the old pid_inmra file"
  rm pid_inmra
fi

#set +x
